<?php
namespace App\Controllers;
use App\Core\Controller;
use App\Models\Exam;
use App\Models\Question;
use App\Models\Achiever;

class AdminController extends Controller {
    public function dashboard() {
        if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
            header('Location: /login'); exit;
        }
        $exams = (new Exam($this->db))->all();
        
        // Fetch Exam Countdowns
        $countdownModel = new \App\Models\ExamCountdown($this->db);
        $countdowns = $countdownModel->getAllCountdowns();

        // Fetch Achievements
        $achievementModel = new \App\Models\Achievement($this->db);
        $achievers = $achievementModel->getAllAchievements();

        $resultModel = new \App\Models\Result($this->db);
        $recentResults = $resultModel->getResults([], 1, 10); // Get first 10 results

        // Fetch Recent Logins
        $recentLogins = [];
        try {
            $stmt = $this->db->prepare("
                SELECT l.*, u.name 
                FROM login_logs l 
                JOIN users u ON l.user_id = u.id 
                ORDER BY l.login_time DESC 
                LIMIT 5
            ");
            $stmt->execute();
            $recentLogins = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        } catch (\Exception $e) {}

        // Fetch Official Links
        $officialLinks = [];
        try {
            $stmt = $this->db->prepare("SELECT * FROM official_links ORDER BY created_at DESC");
            $stmt->execute();
            $officialLinks = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        } catch (\Exception $e) {}

        // Pass all data to the view at once
        $this->view('admin/dashboard.php', [
            'exams' => $exams,
            'countdowns' => $countdowns,
            'achievers' => $achievers,
            'achievers' => $achievers,
            'recentResults' => $recentResults['data'] ?? [],
            'totalResults' => $recentResults['total'] ?? 0,
            'recentLogins' => $recentLogins,
            'officialLinks' => $officialLinks
        ]);
    
    }

    public function getRecentLogins() {
        if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
            http_response_code(403);
            echo json_encode(['error' => 'Unauthorized']);
            exit;
        }

        try {
            $stmt = $this->db->prepare("
                SELECT l.*, u.name, u.email 
                FROM login_logs l 
                JOIN users u ON l.user_id = u.id 
                ORDER BY l.login_time DESC 
                LIMIT 5
            ");
            $stmt->execute();
            $logs = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            
            // Format date for frontend
            foreach ($logs as &$log) {
                $log['formatted_time'] = date('M d, H:i', strtotime($log['login_time']));
                
                if ($log['logout_time']) {
                    $log['formatted_logout'] = date('M d, H:i', strtotime($log['logout_time']));
                    $log['status_class'] = 'text-gray-500'; // Offline/Logged out
                } else {
                    // Check last_activity for timeout (e.g., 5 minutes = 300 seconds)
                    $lastActivity = $log['last_activity'] ? strtotime($log['last_activity']) : strtotime($log['login_time']);
                    $timeSinceActivity = time() - $lastActivity;
                    
                    if ($timeSinceActivity < 300) {
                        $log['formatted_logout'] = 'Online';
                        $log['status_class'] = 'text-green-600 font-bold';
                    } else {
                        $log['formatted_logout'] = 'Offline'; // Timed out
                        $log['status_class'] = 'text-gray-400';
                    }
                }
            }
            
            header('Content-Type: application/json');
            echo json_encode($logs);
        } catch (\Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        exit;
    }

    public function createExam() {
        $this->view('admin/exams_create.php');
    }

    public function postCreateExam() {
        $title = $_POST['title'] ?? '';
        $category = $_POST['category'] ?? '';
        $duration = $_POST['duration'] ?? 60;
        $questions = $_POST['questions'] ?? [];
        
        $examModel = new Exam($this->db);
        $examId = $examModel->createExam($title, $category, $duration, []);
        
        if ($examId && !empty($questions)) {
            $questionModel = new Question($this->db);
            foreach ($questions as $q) {
                if (empty($q['text']) || empty($q['options'])) continue;
                
                $questionModel->createQuestion(
                    $examId,
                    $q['text'],
                    $q['options'],
                    (int)($q['correct_answer'] ?? 0),
                    $q['explanation'] ?? ''
                );
            }
        }
        
        $_SESSION['flash']['success'] = "Exam created successfully.";
        $this->redirect('/admin/dashboard');
    }

    public function addQuestion() {
        $this->view('admin/add_question.php');
    }

    public function postAddQuestion() {
        $examId = $_POST['exam_id'] ?? '';
        $text = $_POST['text'] ?? '';
        $options = [
            $_POST['opt1'] ?? '',
            $_POST['opt2'] ?? '',
            $_POST['opt3'] ?? '',
            $_POST['opt4'] ?? ''
        ];
        $answer = $_POST['answer'] ?? 0;
        (new Question($this->db))->createQuestion($examId, $text, $options, (int)$answer, $_POST['explanation'] ?? '');
        $_SESSION['flash']['success'] = "Question added.";
        $this->redirect('/admin/dashboard');
    }
}
